clc;clear;
cd ..\linkgame\;
linkgame();